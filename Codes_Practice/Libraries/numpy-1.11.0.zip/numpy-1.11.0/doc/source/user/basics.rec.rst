.. _structured_arrays:

*****************
Structured arrays 
*****************

.. automodule:: numpy.doc.structured_arrays
