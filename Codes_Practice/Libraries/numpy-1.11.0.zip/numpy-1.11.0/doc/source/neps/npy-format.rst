.. include:: ../../neps/npy-format.rst
